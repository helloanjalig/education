CS50 WEB PROGRAMMING FINAL PROJECT: Geeksmoon e-education website The project video is: https://youtu.be/YtHHEC-bdqA

Main idea I created a collaborative web application to learn how to code. Everyone can create a talk (which are basically just classes) and everyone can enroll in those classes. The main components are:

Home page Login/Logout/Register Talks page in which there are listed all of the different talks or classes and where you can filter talks by different criterias An individual page for each talk with all of it's information and a button to enroll A page in which you can access all of the talks in which you are enrolled A page to create new talks Distinctiveness and Complexity The page is not similar to anything we have already created. It's not a social media app nor an e-education. It's not similar to other years projects either.

In terms of complexity, I used Django with more than one model (explained below) and several javascript files to the frontend. Moreover, all of the web application is responsive to the different screen sizes (mainly mobile phones and computers).

Files information

An educational website for students and programmers 😊😊😊 Our Educational Website would provide all the education related stuffs: Notes, Sample Papers, Online Video Lectures and courses to crack competitive exams. Students can clear their doubts by sending their questions to our website. We have added Quizzes for Students who are willing to solve problems on different topics. We have also added Interview questions for students who are preparing for placements.

✔ We have made this website as responsive website so, students or users can easily access our website from any device. ✔ Quiz Section is an interesting feature for students which provide them with lots of questions. They can view their scores easily and solutions of every questions. It is completely responsive website, to provide smooth experience...😎

If you like my project, give it a star 😁😁😁